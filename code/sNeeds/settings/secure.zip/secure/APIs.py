sendinblue = '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'
skyroom = 'apikey-52985-306-b2fa00169e37cb99535c973fa176409c'
zarinpal_merchant = 'b740ec84-c351-11e9-8f33-000c295eb8fc'
